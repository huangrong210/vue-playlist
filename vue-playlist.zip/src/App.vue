<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-09-02 16:09:40
 * @LastEditTime: 2019-09-02 21:25:59
 * @LastEditors: Please set LastEditors
 -->
<!-- 根组件 -->
<!-- 1模板：HTML结构 -->
<template>
  <div id="app">
    <ul>
      <li>
        <router-link to="/">Home</router-link>
        <!-- <a href="/">Home</a> -->
      </li>
      <li>
        <router-link to="/helloworld">Hello</router-link>
        <!-- <a href="/helloworld">Hello</a> -->
      </li>
    </ul>
    <router-view></router-view>
  </div>
</template>

<!-- 2行为:处理逻辑 -->
<script>
    export default {
        name: "App",
        data() {
            return {

            }
        }
    };
</script>

<!-- 3样式:解决样式 -->
<style scoped>
    h1 {
        color: purple;
    }
</style>