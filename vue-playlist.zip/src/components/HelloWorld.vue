<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-09-02 16:09:40
 * @LastEditTime: 2019-09-02 21:21:14
 * @LastEditors: Please set LastEditors
 -->
<!-- 子组件 -->
<template>
  <div class="hello">
    Hello World
  </div>
</template>

<script>
    export default {
        name: 'HelloWorld',
        data() {
            return {

            }
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>