<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-09-02 16:09:40
 * @LastEditTime: 2019-09-02 21:07:12
 * @LastEditors: Please set LastEditors
 -->
<!-- 子组件 -->
<template>
  <footer>
    <p>{{copyright}}{{title}}</p>
  </footer>
</template>

<script>
    export default {
        name: 'app-footer',
        props: {
            title: {
                type: String,
                // required: true
            }
        },
        data() {
            return {
                copyright: "Copyright 2019 Vue Demo"
            }
        }
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    footer {
        background: #222;
        padding: 6px;
    }
    
    p {
        color: lightgreen;
        text-align: center;
    }
</style>