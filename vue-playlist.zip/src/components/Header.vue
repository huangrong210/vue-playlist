<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-09-02 16:09:40
 * @LastEditTime: 2019-09-02 21:09:13
 * @LastEditors: Please set LastEditors
 -->
<!-- 子组件 -->
<template>
  <header @click="changeTitle">
    <h1>{{title1}}{{title}}</h1>
  </header>
</template>

<script>
    export default {
        name: 'app-header',
        props: {
            title: {
                type: String,
                // required: true
            }
        },
        data() {
            return {
                title1: "Vue.js Demo"
            }
        },
        methods: {
            changeTitle() {
                // this.title = "changed"
                this.$emit("titleChanged", "子向父组件传值")
            }
        },
        // beforeCreate() {
        //     alert("组件实例化之前执行的函数")
        // },
        // created() {
        //     alert("组件实例化完毕，但页面还未显示")
        // },
        // beforeMount() {
        //     alert("组件挂载前，页面仍未显示，但虚拟DOM已经配置")
        // },
        // mounted() {
        //     alert("组件挂载后，此方法执行后，页面显示")
        // },
        // beforeUpdate() {
        //     alert("组件更新前，页面仍未显示，但虚拟DOM已经配置")
        // },
        // updated() {
        //     alert("组件更新，此方法执行后，页面显示")
        // },
        // beforeDestroy() {
        //     alert("组件销毁前")
        // },
        // destroyed() {
        //     alert("组件销毁")
        // },
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    header {
        background: #90ee90;
        padding: 10px;
    }
    
    h1 {
        color: #222;
        text-align: center;
    }
</style>