<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-09-02 16:09:40
 * @LastEditTime: 2019-09-02 21:34:04
 * @LastEditors: Please set LastEditors
 -->
<!-- 子组件 -->
<template>
  <div class="users">
    <h1>Hello Users</h1>
    <ul>
      <!-- <li v-for="user in users" @click="user.show=!user.show"> -->
      <li v-for="user in users">
        <h2>{{user.name}}</h2>
        <!-- <h3 v-show="user.show">{{user.position}}</h3> -->
        <h3>{{user.email}}</h3>
      </li>
    </ul>
    <button @click="deleteUser">删除</button>
  </div>
</template>

<!--
  传值：string number boolean
  引用：array object
 -->

<script>
    export default {
        name: 'users',
        // props: ["users"], //属性传值
        props: {
            // 属性传值 标准写法
            users: {
                type: Array,
                required: true,
            }
        },
        data() {
            return {
                users: []
            }
        },
        methods: {
            deleteUser: () => this.users.pop()
        },
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .users {
        width: 100%;
        max-width: 1200px;
        margin: 40px auto;
        padding: 0 20px;
        box-sizing: border-box;
    }
    
    ul {
        display: flex;
        flex-wrap: wrap;
        list-style-type: none;
        padding: 0;
    }
    
    li {
        flex-grow: 1;
        flex-basis: 200px;
        text-align: center;
        padding: 30px;
        border: 1px solid #222;
        margin: 10px;
    }
</style>