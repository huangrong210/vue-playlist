<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-09-02 16:09:40
 * @LastEditTime: 2019-09-02 21:32:47
 * @LastEditors: Please set LastEditors
 -->
<!-- 根组件 -->
<!-- 1模板：HTML结构 -->
<template>
  <div id="home">
    <app-header @titleChanged="updateTitle($event)" :title="title"></app-header>
    <!-- <app-header :title="title"></app-header> -->
    <!-- 属性传值 -->
    <users :users="users"></users>
    <users :users="users"></users>
    <app-footer :title="title"></app-footer>
  </div>
</template>

<!-- 2行为:处理逻辑 -->
<script>
    // 局部注册组件
    import Users from './Users'
    import Header from './Header'
    import Footer from './Footer'

    export default {
        name: "home",
        data() {
            return {
                // title: "这是我的第一个Vue脚手架项目！",
                users: [
                    //   {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // }, {
                    //     name: "Henry",
                    //     position: "Web开发",
                    //     show: false
                    // },
                ],
                title: "传递的是一个值，（number string Boolean）"
            }
        },
        methods: {
            updateTitle(title) {
                this.title = title;
            }
        },
        components: {
            "users": Users,
            // Users
            "app-header": Header,
            "app-footer": Footer,
        },
        created() {
            this.$http.get("http://jsonplaceholder.typicode.com/users").then((data => {
                // console.log(data)
                this.users = data.body
            }))
        },
    };
</script>

<!-- 3样式:解决样式 -->
<style scoped>
    h1 {
        color: purple;
    }
</style>